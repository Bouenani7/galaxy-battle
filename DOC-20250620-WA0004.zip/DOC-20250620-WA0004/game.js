
// هذه نسخة مبسطة من كود اللعبة مع تأثيرات ومؤشرات
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

let level = 1;
let score = 0;
let timeLeft = 60;
let gameInterval;
let timerInterval;

function startGame() {
  document.getElementById('start-screen').style.display = 'none';
  document.getElementById('end-screen').style.display = 'none';
  level = 1;
  score = 0;
  timeLeft = 60;
  updateUI();
  gameInterval = setInterval(gameLoop, 1000 / 60);
  timerInterval = setInterval(() => {
    timeLeft--;
    document.getElementById('timer').textContent = timeLeft;
    if (timeLeft <= 0) nextLevel();
  }, 1000);
}

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBackground();
  drawPlayer();
  drawEnemies();
  drawUI();
}

function drawBackground() {
  // رسم نجوم متحركة (مبسط)
  ctx.fillStyle = 'white';
  for(let i = 0; i < 100; i++) {
    ctx.fillRect(Math.random() * canvas.width, Math.random() * canvas.height, 1, 1);
  }
}

function drawPlayer() {
  ctx.fillStyle = 'cyan';
  ctx.fillRect(canvas.width/2 - 15, canvas.height - 60, 30, 30);
}

function drawEnemies() {
  ctx.fillStyle = 'red';
  for(let i = 0; i < 5; i++) {
    ctx.fillRect(50 + i*150, 50, 30, 30);
  }
}

function drawUI() {
  document.getElementById('level').textContent = level;
  document.getElementById('score').textContent = score;
}

function nextLevel() {
  clearInterval(gameInterval);
  clearInterval(timerInterval);
  level++;
  if(level > 10) endGame();
  else {
    timeLeft = 60;
    updateUI();
    gameInterval = setInterval(gameLoop, 1000 / 60);
    timerInterval = setInterval(() => {
      timeLeft--;
      document.getElementById('timer').textContent = timeLeft;
      if (timeLeft <= 0) nextLevel();
    }, 1000);
  }
}

function endGame() {
  clearInterval(gameInterval);
  clearInterval(timerInterval);
  document.getElementById('end-screen').style.display = 'flex';
  document.getElementById('final-score').textContent = score;
}

function restartGame() {
  startGame();
}

function updateUI() {
  document.getElementById('level').textContent = level;
  document.getElementById('score').textContent = score;
  document.getElementById('timer').textContent = timeLeft;
}
